package com.example.androidbarberbookingapp.Common;

public class Common {
    public static String IS_LOGIN = "IsLogin";
}
